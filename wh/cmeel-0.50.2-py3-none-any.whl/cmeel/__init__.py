"""Cmeel module."""
# ruff: noqa: F401

from .build import build_editable, build_sdist, build_wheel
from .cmeel import __author__, __license__, __project_name__, __version__
